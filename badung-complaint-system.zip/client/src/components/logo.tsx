import React from "react";
import { Link } from "wouter";

type LogoProps = {
  size?: "small" | "medium" | "large";
  showText?: boolean;
};

export function Logo({ size = "medium", showText = true }: LogoProps) {
  let imgSize: string;
  let textSize: string;
  
  switch (size) {
    case "small":
      imgSize = "h-8";
      textSize = "text-base";
      break;
    case "large":
      imgSize = "h-14";
      textSize = "text-2xl";
      break;
    default:
      imgSize = "h-12";
      textSize = "text-xl";
  }

  return (
    <Link href="/" className="flex items-center cursor-pointer">
      <img
        src="/assets/logo.png"
        alt="Logo Kabupaten Badung"
        className={`${imgSize} mr-3`}
      />
      {showText && (
        <div>
          <h1 className={`${textSize} font-heading font-bold text-primary`}>
            Portal Pengaduan Masyarakat
          </h1>
          <p className="text-sm text-neutral-dark">Pemerintah Kabupaten Badung</p>
        </div>
      )}
    </Link>
  );
}
